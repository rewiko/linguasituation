<?php

$lang['ut_test_name'] = 'نام تست';
$lang['ut_test_datatype'] = 'نوع دیتای تست';
$lang['ut_res_datatype'] = 'نوع دیتای مورد انتظار';
$lang['ut_result'] = 'نتیجه';
$lang['ut_undefined'] = 'نام تست نامشخص';
$lang['ut_file'] = 'نام فایل';
$lang['ut_line'] = 'شماره خط';
$lang['ut_passed'] = 'پاس شده';
$lang['ut_failed'] = 'پاس نشده';
$lang['ut_boolean'] = 'منطقی';
$lang['ut_integer'] = 'عددی';
$lang['ut_float'] = 'عددی اعشاری';
$lang['ut_double'] = 'عددی اعشاری';
$lang['ut_string'] = 'رشته';
$lang['ut_array'] = 'آرایه';
$lang['ut_object'] = 'آبجکت';
$lang['ut_resource'] = 'ریسورس';
$lang['ut_null'] = 'خالی';
$lang['ut_notes'] = 'یادداشت';
?>