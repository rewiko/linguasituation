<?php

$lang['ut_test_name'] = 'Testi Nimi';
$lang['ut_test_datatype'] = 'Testi Andmet&uuml;&uuml;p';
$lang['ut_res_datatype'] = 'Arvatav Andmet&uuml;&uuml;p';
$lang['ut_result'] = 'Tulemus';
$lang['ut_undefined'] = 'M&auml;&auml;ramata testi nimi';
$lang['ut_file'] = 'Faili Nimi';
$lang['ut_line'] = 'Rea numbers';
$lang['ut_passed'] = 'Korras';
$lang['ut_failed'] = 'Ei l&auml;binud';
$lang['ut_boolean'] = 'Muutuja';
$lang['ut_integer'] = 'T&auml;isarv';
$lang['ut_float'] = 'Float';
$lang['ut_double'] = 'Float';
$lang['ut_string'] = 'Jada';
$lang['ut_array'] = 'Massiiv';
$lang['ut_object'] = 'Objekt';
$lang['ut_resource'] = 'Vahendid';
$lang['ut_null'] = 'Null';
$lang['ut_notes'] = '';
$lang[''] = '';
?>