<?php

$lang['imglib_source_image_required'] = 'Sa pead m&auml;&auml;rama pildi p&auml;ritolu oma seadistustes.';
$lang['imglib_gd_required'] = 'GD image library on vajalik selle muganduse kasutamiseks.';
$lang['imglib_gd_required_for_props'] = 'Sinu server peab toetama GD image library toiminguid, et kindlaks m&auml;&auml;rata pildi s&auml;tteid.';
$lang['imglib_unsupported_imagecreate'] = 'Sinu server ei toeta GD toimnguid mida oin vaja k&auml;esoleva faili t&ouml;&ouml;tlemiseks.';
$lang['imglib_gif_not_supported'] = 'GIF vormingus pilte sageli ei toetata t&auml;nu litsensi piirangutele.  Kui vaja pead kasutama JPG v&otilde;i PNG t&uuml;&uuml;pi pildi vormingut.';
$lang['imglib_jpg_not_supported'] = 'JPG vormingut ei toetata.';
$lang['imglib_png_not_supported'] = 'PNG vormingut ei toetata.';
$lang['imglib_jpg_or_png_required'] = 'Seadistuses m&auml;&auml;ratud pildi suuruse muutmise protokoll t&ouml;&ouml;tab ainult JEPG ja PNG pildi t&uuml;&uuml;pidega.';
$lang['imglib_copy_error'] = 'Ilmnes viga pildi faili asendamise k&auml;igus.  Veenduge, et kasuta on lubatud kirjutada.';
$lang['imglib_rotate_unsupported'] = 'Pildi p&ouml;&ouml;ramine ei tundu olevat lubatud teie serveri poolt.';
$lang['imglib_libpath_invalid'] = 'Aadressi jada pildipangani ei ole &otilde;ige.  Palun seadistage oma eelistuste faili.';
$lang['imglib_image_process_failed'] = 'Pildit&ouml;&ouml;tlus eba&otilde;nnestus.  Palun veenduge, et teie server toetab valitud protokolli ja aadressi jada pildipangani on &otilde;ige.';
$lang['imglib_rotation_angle_required'] = 'Pildikeeramiseks on vaja m&auml;&auml;rata p&ouml;&ouml;rdenurk.';
$lang['imglib_writing_failed_gif'] = 'GIF pilt.';
$lang['imglib_invalid_path'] = 'Aadressijada pildini ei ole &otilde;ige.';
$lang['imglib_copy_failed'] = 'Pildi kopeerimise toiming eba&otilde;nnestus.';
$lang['imglib_missing_font'] = 'Ei &otilde;nnestunud leida kasutatavat fonti.';
$lang['imglib_save_failed'] = '';
?>