<?php

$lang['ftp_no_connection'] = '&Uuml;henduse ID tunnust polnud v&otilde;imalik tuvastada.  Veenduge, et olete &uuml;henduse saavutanud enne kui asute teostama toiminguid andmetega.';
$lang['ftp_unable_to_connect'] = 'Ei saanud &uuml;hendust FTP serveriga antud aadressil.';
$lang['ftp_unable_to_login'] = 'Ei saanud &uuml;hendust FTP serveriga.  Palun kontrollige kasutajanime ja salas&otilde;na.';
$lang['ftp_unable_to_makdir'] = 'M&auml;&auml;ratud kausta loomine eba &otilde;nnestus.';
$lang['ftp_unable_to_changedir'] = 'Kausta vahetamine eba&otilde;nnestus.';
$lang['ftp_unable_to_chmod'] = 'Ei saa seadistada failide &otilde;igusi.  Veenduge aadressi &otilde;igsuses.  T&auml;helepanu: see v&otilde;imalus on ainult PHP 5 versioonis ja uuemates.';
$lang['ftp_unable_to_upload'] = 'M&auml;&auml;ratud faili ei &otilde;nnestunud &uuml;les laadida.  Veenduge aadressi &otilde;igsuses.';
$lang['ftp_unable_to_download'] = '';
$lang['ftp_no_source_file'] = 'L&auml;hte faili ei &otilde;nnestu leida.  Veenduge aadressi &otilde;igsuses.';
$lang['ftp_unable_to_rename'] = 'Faili nime muutmine ei &otilde;nnestunud.';
$lang['ftp_unable_to_delete'] = 'Faili kustutamine eba&otilde;nnestus.';
$lang['ftp_unable_to_move'] = 'Faili teisaldamine eba&otilde;nnestus. Veendu, et sihtkaust on olemas.';
$lang[''] = '';
?>