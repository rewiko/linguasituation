<?php

$lang['upload_userfile_not_set'] = 'Ei leia muutujat nimega kasutaja fail.';
$lang['upload_file_exceeds_limit'] = '&Uuml;leslaetava faili suurus on enam kui lubatud PHP seadistustes.';
$lang['upload_file_exceeds_form_limit'] = '&Uuml;leslaetava faili suurus &uuml;letab laadimisvormis lubatud suurust.';
$lang['upload_file_partial'] = 'Fail sai &uuml;leslaetud poolikult.';
$lang['upload_no_temp_directory'] = 'Ajutine kaust puudub.';
$lang['upload_unable_to_write_file'] = 'Faili ei saanud kettale kirjutada.';
$lang['upload_stopped_by_extension'] = '&Uuml;leslaadimine peatatati laiendi poolt.';
$lang['upload_no_file_selected'] = 'Sa ei valinud faili mida &uuml;les laadida.';
$lang['upload_invalid_filetype'] = 'Faili t&uuml;&uuml;p mida sa p&uuml;&uuml;ad &uuml;les laadida ei ole lubatud.';
$lang['upload_invalid_filesize'] = 'Faili mida sa p&uuml;&uuml;ad &uuml;les laadida on lubatust suurem.';
$lang['upload_invalid_dimensions'] = 'Pilt mida sa proovid &uuml;les ladida on suurem lubatust k&otilde;rguselt/laiuselt.';
$lang['upload_destination_error'] = 'Ilmens viga, p&uuml;&uuml;des teisaldada &uuml;leslaetud faili tema l&otilde;pplikule kohale.';
$lang['upload_no_filepath'] = '&Uuml;leslaadimise adress ei tundu &otilde;ige olevat.';
$lang['upload_no_file_types'] = 'Sa ei ole m&auml;&auml;ranud &uuml;htegi lubatud faili t&uuml;&uuml;pi.';
$lang['upload_bad_filename'] = 'Sinu pakutud nimega fail on juba serveris olemas.';
$lang['upload_not_writable'] = '&Uuml;leslaadimise kausta ei saa kirjutada.';
?>