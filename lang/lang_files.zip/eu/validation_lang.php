<?php

$lang['required'] = '%s eremua beharrezkoa da.';
$lang['isset'] = '%s eremuak balio bat behar du.';
$lang['valid_email'] = '%s eremuak baliozko eposta helbidea behar du.';
$lang['valid_emails'] = '%s eremuak baliozko eposta helbideak behar ditu.';
$lang['valid_url'] = '%s eremuak baliozko URLa behar du.';
$lang['valid_ip'] = '%s eremuak baliozko IPa behar du.';
$lang['min_length'] = '%s eremuaren luzerak %s karaktere behar ditu gutxienez.';
$lang['max_length'] = '%s eremuaren luzerak %s karaktere behar ditu gehienez.';
$lang['exact_length'] = '%s eremuaren luzerak %s karaktere izan behar ditu.';
$lang['alpha'] = '%s eremuak karaktere alfabetikoak bakarrik onartzen ditu.';
$lang['alpha_numeric'] = '%s eremuak karaktere alfanumerikoak bakarrik onartzen ditu.';
$lang['alpha_dash'] = '%s eremuak karaktere alfabetikoak, azpimarrak eta marratxoak bakarrik onartzen ditu.';
$lang['numeric'] = '%s eremuak zenbakiak bakarrik onartzen ditu.';
$lang['integer'] = '%s eremuak zenbaki osoak bakarrik onartzen ditu.';
$lang['matches'] = '%s eremua ez dator bat %s eremuarekin.';
?>