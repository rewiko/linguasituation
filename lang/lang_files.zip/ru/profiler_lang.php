<?php

$lang['profiler_database'] = 'БАЗА ДАННЫХ';
$lang['profiler_controller_info'] = 'КЛАСС/МЕТОД';
$lang['profiler_benchmarks'] = 'ПРОИЗВОДИТЕЛЬНОСТЬ';
$lang['profiler_queries'] = 'ЗАПРОСЫ';
$lang['profiler_get_data'] = 'ДАННЫЕ ИЗ GET';
$lang['profiler_post_data'] = 'ДАННЫЕ ИЗ POST';
$lang['profiler_uri_string'] = 'СТРОКА URI';
$lang['profiler_memory_usage'] = 'ИСПОЛЬЗОВАНИЕ ПАМЯТИ';
$lang['profiler_config'] = '';
$lang['profiler_headers'] = '';
$lang['profiler_no_db'] = 'Драйвер БД не был загружен';
$lang['profiler_no_queries'] = 'Ни одного запроса не было выполнено';
$lang['profiler_no_post'] = 'Отсутствуют данные, переданные методом POST';
$lang['profiler_no_get'] = 'Отсутствуют данные, переданные методом GET';
$lang['profiler_no_uri'] = 'Отсутствуют данные, переданные в URI';
$lang['profiler_no_memory'] = 'Использование памяти невозможно';
$lang['profiler_no_profiles'] = '';
$lang[''] = '';
?>