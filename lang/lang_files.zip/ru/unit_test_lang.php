<?php

$lang['ut_test_name'] = 'Имя теста';
$lang['ut_test_datatype'] = 'Тестируемый тип данных';
$lang['ut_res_datatype'] = 'Ожидаемый тип данных';
$lang['ut_result'] = 'Результат';
$lang['ut_undefined'] = 'Имя теста неопределено';
$lang['ut_file'] = 'Имя файла';
$lang['ut_line'] = 'Номер строки';
$lang['ut_passed'] = 'Верно';
$lang['ut_failed'] = 'Неудача';
$lang['ut_boolean'] = 'Булево';
$lang['ut_integer'] = 'Целое';
$lang['ut_float'] = 'С плакавщей точкой';
$lang['ut_double'] = 'С плакавщей точкой';
$lang['ut_string'] = 'Строка';
$lang['ut_array'] = 'Массив';
$lang['ut_object'] = 'Объект';
$lang['ut_resource'] = 'Ресурс';
$lang['ut_null'] = 'Пусто';
$lang['ut_notes'] = '';
$lang[''] = '';
?>