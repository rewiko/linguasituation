<?php

$lang['upload_userfile_not_set'] = 'Үҙгәреүсән userfile POST массивынан алынған мәғлүмәт араһында табылмай.';
$lang['upload_file_exceeds_limit'] = 'Төйәлгән файл серверға төйәргә рөхсәт ителгән файл күләменән артығыраҡ.';
$lang['upload_file_exceeds_form_limit'] = '';
$lang['upload_file_partial'] = 'Был файл өлөшләтә төйәлде.';
$lang['upload_no_temp_directory'] = '';
$lang['upload_unable_to_write_file'] = '';
$lang['upload_stopped_by_extension'] = '';
$lang['upload_no_file_selected'] = 'Һеҙ төйәү өсөн файлды һайламағанһығыҙ.';
$lang['upload_invalid_filetype'] = 'Һеҙ тыйылған файл тибын төйәргә маташаһығыҙ.';
$lang['upload_invalid_filesize'] = 'Һеҙ төйәргә маташҡан файл сикләнгән күләмдән арта.';
$lang['upload_invalid_dimensions'] = 'Һеҙ төйәргә маташҡан һүрәт сикләнгән киңлектән/юғарылыҡтан арта';
$lang['upload_destination_error'] = 'Файлды күрһәтелгән урынға төйәүҙән һуң күсереп булмай.';
$lang['upload_no_filepath'] = 'Файлдарҙы төйәү юлы дөрөҫ түгел.';
$lang['upload_no_file_types'] = 'Рөхсәт ителгән файл типтарын күрһәтмәгәнһегеҙ.';
$lang['upload_bad_filename'] = 'Һеҙ төйәргә маташҡан файл серверҙа бар инде.';
$lang['upload_not_writable'] = 'Файлдарҙы төйәү директорияһының яҙмаға хоҡуғы юҡ ахыры.';
$lang[''] = '';
?>