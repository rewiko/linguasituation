<?php

$lang['ut_test_name'] = 'Тест исеме';
$lang['ut_test_datatype'] = 'Тест үткәрелгән мәғлүмәт тибы ';
$lang['ut_res_datatype'] = 'Көтөлгән мәғлүмәт тибы';
$lang['ut_result'] = 'Һөҙөмтә';
$lang['ut_undefined'] = 'Тест исеме билдәләнмәгән';
$lang['ut_file'] = 'Файл исеме';
$lang['ut_line'] = 'юл номеры';
$lang['ut_passed'] = 'Дөрөҫ';
$lang['ut_failed'] = 'Уңышһыҙлыҡ';
$lang['ut_boolean'] = 'булево';
$lang['ut_integer'] = 'Бөтөн';
$lang['ut_float'] = 'йөҙгән нөктәле';
$lang['ut_double'] = 'йөҙгән нөктәле';
$lang['ut_string'] = 'юл';
$lang['ut_array'] = 'массив';
$lang['ut_object'] = 'объект';
$lang['ut_resource'] = 'ресурс';
$lang['ut_null'] = '';
$lang['ut_notes'] = '';
$lang[''] = '';
?>