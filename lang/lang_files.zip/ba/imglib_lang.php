<?php

$lang['imglib_source_image_required'] = 'Тәүге һүрәттең файл исемен күрһәтегеҙ.';
$lang['imglib_gd_required'] = 'Был операцияны үтәр өсөн GD китапханаһы кәрәк.';
$lang['imglib_gd_required_for_props'] = 'Һүрәт сифаттарҙың мәғәнәһен ҡабул итер өсөн Һеҙҙең серверҙа GD китапханаһы бирелергә тейеш.';
$lang['imglib_unsupported_imagecreate'] = 'Һеҙҙең серверҙа был һүрәт тибы менән эш итеү функцияһы юҡ.';
$lang['imglib_gif_not_supported'] = 'Ғәҙәттә GIF һүрәттәр менән эш итеү лицензия сикләүе менән бәйле. Уның урынына Һеҙ JPG йә PNG ҡуллана алаһығыҙ.';
$lang['imglib_jpg_not_supported'] = 'JPG менән эш итеү мөмкинселеге ҡуйылмаған';
$lang['imglib_png_not_supported'] = 'PNG менән эш итеү мөмкинселеге ҡуйылмаған ';
$lang['imglib_jpg_or_png_required'] = 'Һеҙ һайлаған һүрәт эшкәртеү китапханаһы фәҡәт JPG йә PNG-файлдарҙы хуплай.';
$lang['imglib_copy_error'] = 'Файлды яңынан күсереп яҙырға маташҡанда хата. Был директория өсөн яҙыу рөхсәт ителгәненә инанығыҙ.';
$lang['imglib_rotate_unsupported'] = 'Һүрәтте бороу китапхана тарафынан хупланмай шикелле.';
$lang['imglib_libpath_invalid'] = 'Һүрәт эшкәртеү китапханаһына юл дөрөҫ бирелмәгән. Зинһар уны төҙәтегеҙ.';
$lang['imglib_image_process_failed'] = 'Һүрәтте эшкәртеп булмай. Һеҙҙең сервер Һеҙ һайлаған һүрәт эшкәртеү пакетын хуплауына инанығыҙ һәм был пакеттарға булған юлдың дөрөҫлөгөн тикшерегеҙ.';
$lang['imglib_rotation_angle_required'] = 'Һүрәтте борор өсөн мөйөш мәғәнәһен күрһәтергә кәрәк.';
$lang['imglib_writing_failed_gif'] = 'GIF image ';
$lang['imglib_invalid_path'] = ' Һүрәткә юл дөрөҫ бирелмәгән.';
$lang['imglib_copy_failed'] = 'Һүрәт файлын күсереү функцияһын үтәп булмай.';
$lang['imglib_missing_font'] = 'Шрифт табылманы.';
$lang['imglib_save_failed'] = '';
$lang[''] = '';
?>