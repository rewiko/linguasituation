<?php

$lang['email_must_be_array'] = 'E-mail тикшереү ысулы массив аша ебәрелергә тейеш.';
$lang['email_invalid_address'] = '%s – яңылыш e-mail ';
$lang['email_attachment_missing'] = '%s хаты өсөн ҡушылманы табып булмай';
$lang['email_attachment_unreadable'] = '';
$lang['email_no_recipients'] = 'To, Cc, йәки Bcc юлдарында хәбәр алыусыларҙы күрһәтеү кәрәк';
$lang['email_send_failure_phpmail'] = 'PHP mail() функцияһы ярҙамында хат ебәреп булмай. Серверҙы тейешле рәүештә көйләгәндә был мөмкин.';
$lang['email_send_failure_sendmail'] = 'sendmail ҡулланып хат ебәреп булмай. Серверҙы тейешле рәүештә көйләгәндә был мөмкин.';
$lang['email_send_failure_smtp'] = 'SMTP ҡулланып хат ебәреп булмай. Серверҙы тейешле рәүештә көйләгәндә был мөмкин.';
$lang['email_sent'] = 'Хәбәрегеҙ уңышлы ебәрелде. %s протоколы ҡулланылды';
$lang['email_no_socket'] = 'Sendmail-ға сокет-тоташыу мөмкин түгел. Зинһар көйләүҙе тикшерегеҙ.';
$lang['email_no_hostname'] = 'Һеҙ SMTP серверын күрһәтмәнегеҙ';
$lang['email_smtp_error'] = '%s SMTP аша мәғлүмәт ебәргәндә хата бар';
$lang['email_no_smtp_unpw'] = 'Хата: Ҡулланыусы исемен һәм SMTP өсөн парольде яҙығыҙ.';
$lang['email_failed_smtp_login'] = '';
$lang['email_smtp_auth_un'] = 'Ҡулланыусы исеменә аутентификация үткәреп булмай. Хата: %s';
$lang['email_smtp_auth_pw'] = 'Парольде аутентификациялап булмай. Хата: %s';
$lang['email_smtp_data_failure'] = '%s Мәғлүмәтте ебәреп булмай.';
$lang['email_exit_status'] = '';
$lang[''] = '';
?>