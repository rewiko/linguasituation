<?php

$lang['profiler_database'] = '';
$lang['profiler_controller_info'] = '';
$lang['profiler_benchmarks'] = 'ЕТЕШТЕРЕҮСӘНЛЕК';
$lang['profiler_queries'] = 'ТАЛАПТАР';
$lang['profiler_get_data'] = '';
$lang['profiler_post_data'] = 'POST-ысулы мәғлүмәттәре';
$lang['profiler_uri_string'] = '';
$lang['profiler_memory_usage'] = '';
$lang['profiler_config'] = '';
$lang['profiler_headers'] = '';
$lang['profiler_no_db'] = 'Мәғлүмәттәр нигеҙе драйверы төйәлмәгән';
$lang['profiler_no_queries'] = 'Бер талап та үтәлмәне';
$lang['profiler_no_post'] = 'POST-ысулы менән ебәрелгән мәғлүмәттәр юҡ кимәлендә';
$lang['profiler_no_get'] = '';
$lang['profiler_no_uri'] = '';
$lang['profiler_no_memory'] = '';
$lang['profiler_no_profiles'] = '';
$lang[''] = '';
?>