<?php

$lang['ut_test_name'] = 'Nume Test';
$lang['ut_test_datatype'] = 'Test Tip Informatie';
$lang['ut_res_datatype'] = 'Tip Informatie Asteptat';
$lang['ut_result'] = 'Rezultat';
$lang['ut_undefined'] = 'Test Nume Nedefinit';
$lang['ut_file'] = 'Nume Fisier';
$lang['ut_line'] = 'Numar Rand';
$lang['ut_passed'] = 'Trecut';
$lang['ut_failed'] = 'Esuat';
$lang['ut_boolean'] = 'Boolean';
$lang['ut_integer'] = 'Integer';
$lang['ut_float'] = 'Float';
$lang['ut_double'] = 'Float';
$lang['ut_string'] = 'String';
$lang['ut_array'] = 'Array';
$lang['ut_object'] = 'Obiect';
$lang['ut_resource'] = 'Resursa';
$lang['ut_null'] = 'Null';
$lang['ut_notes'] = '';
$lang[''] = '';
?>