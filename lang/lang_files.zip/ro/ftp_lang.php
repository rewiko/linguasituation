<?php

$lang['ftp_no_connection'] = 'Conexiunea nu a putut fi realizata. Va ruga verificati ca sunteti conectat inainte de a efectua orice modificare la fisiere.';
$lang['ftp_unable_to_connect'] = 'Conexiunea FTP nu a putut fi realizata utilizand hostname-ul precizat.';
$lang['ftp_unable_to_login'] = 'Logarea catre serverul FTP nu a putu fi realizata. Va rugam verificati utilizatorul si parola.';
$lang['ftp_unable_to_makdir'] = 'Crearea directorului speficiat nu s-a putut realiza.';
$lang['ftp_unable_to_changedir'] = 'Schimbarea directoarelor nu a avut loc.';
$lang['ftp_unable_to_chmod'] = 'Permisiunea fisierului nu a putut fi schimbata. Va rugam verificati calea. Sfat: Aceasta trasatura e valabila doar pentru PHP 5 sau o versiunea ulterioara.';
$lang['ftp_unable_to_upload'] = 'Upload catre directorul specificat imposibil. Va rugam verificati calea.';
$lang['ftp_unable_to_download'] = '';
$lang['ftp_no_source_file'] = 'Fisierul sursa nu a putut fi localizat. Va rugam verificati calea.';
$lang['ftp_unable_to_rename'] = '';
$lang['ftp_unable_to_delete'] = 'Stergerea fisierului nu a avut loc.';
$lang['ftp_unable_to_move'] = 'Mutarea fisierului nu a avut loc. Va rugam verificati daca directorul exista.';
$lang[''] = '';
?>