<?php

$lang['upload_userfile_not_set'] = 'Datos, kas iegūti no masīva POST, neizdevās atrast mainīgo ar nosaukumu Userfile.';
$lang['upload_file_exceeds_limit'] = 'Augšupielādējamās datnes izmērs pārsniedz PHP konfigurācijas failā norādīto atļauto maksimālo apjomu.';
$lang['upload_file_exceeds_form_limit'] = 'Augšupielādējamās datnes izmērs pārsniedz ielādēšanas logā norādīto atļauto maksimālo apjomu.';
$lang['upload_file_partial'] = 'Datnes augšupielāde tika veikta tikai daļēji.';
$lang['upload_no_temp_directory'] = 'Nav pagaidu mapes.';
$lang['upload_unable_to_write_file'] = 'Datnes ierakstīšana diskā neizdevās.';
$lang['upload_stopped_by_extension'] = 'Nepareiza paplašinājuma dēļ datnes augšupielāde tika apturēta.';
$lang['upload_no_file_selected'] = 'Jūs aizmirsāt izvēlēties augšupielādējamo datni.';
$lang['upload_invalid_filetype'] = 'Jūs cenšaties augšupielādēt aizliegta tipa datni.';
$lang['upload_invalid_filesize'] = 'Augšupielādējamās datnes izmērs pārsniedz pieļaujamo apjomu.';
$lang['upload_invalid_dimensions'] = 'Augšupielādējamā attēla garums vai platums pārsniedz noteiktos ierobežojumus.';
$lang['upload_destination_error'] = 'Augšupielādēto datni uz Jūsu norādīto vietu pārvietot neizdevās.';
$lang['upload_no_filepath'] = 'Datņu augšupielādes ceļš ir nepareizs.';
$lang['upload_no_file_types'] = 'Jūs aizmirsāt norādīt atļautos datņu tipus.';
$lang['upload_bad_filename'] = 'Datne ar šādu nosaukumu jau atrodas serverī.';
$lang['upload_not_writable'] = 'Augšupielādes direktorijā, visticamāk, nav ļauts veikt ierakstu.';
?>