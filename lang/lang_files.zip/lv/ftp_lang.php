<?php

$lang['ftp_no_connection'] = 'Neizdodas izveidot savienojumu. Pirms operācijām ar datnēm pārliecinieties, ka esat pieslēdzies serverim.';
$lang['ftp_unable_to_connect'] = 'Neizdodas izveidot savienojumu ar Jūsu norādīto FTP serveri.';
$lang['ftp_unable_to_login'] = 'Neizdodas pieteikties norādītajā FTP serverī.  Lūdzu, pārbaudiet lietotājvārdu un paroli.';
$lang['ftp_unable_to_makdir'] = 'Jūsu norādītā direktorija izveide neizdevās.';
$lang['ftp_unable_to_changedir'] = 'Direktoriju maiņa neizdevās.';
$lang['ftp_unable_to_chmod'] = 'Datnes atļaujas atribūtu iestatīšana neizdevās.  Lūdzu, pārbaudiet ceļu.  Piezīme: Šī iespēja eksistē vienīgi PHP 5 vai vēlākās versijās.';
$lang['ftp_unable_to_upload'] = 'Norādītās datnes augšupielāde neizdevās.  Lūdzu, pārbaudiet ceļu.';
$lang['ftp_unable_to_download'] = '';
$lang['ftp_no_source_file'] = 'Izejas datni neizdevās atrast.  Lūdzu, pārbaudiet ceļu.';
$lang['ftp_unable_to_rename'] = 'Datnes pārdēvēšana neizdevās.';
$lang['ftp_unable_to_delete'] = 'Datnes izdzēšana neizdevās.';
$lang['ftp_unable_to_move'] = 'Datnes pārvietošana neizdevās.  Pārliecinieties, ka eksistē gala direktorija.';
$lang[''] = '';
?>