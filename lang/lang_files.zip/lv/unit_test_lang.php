<?php

$lang['ut_test_name'] = 'Testa nosaukums';
$lang['ut_test_datatype'] = 'Testā izmantoto datu tips';
$lang['ut_res_datatype'] = 'Iegūstamo datu tips';
$lang['ut_result'] = 'Rezultāts';
$lang['ut_undefined'] = 'Testa nosaukums nav noteikts';
$lang['ut_file'] = 'Datnes nosaukums';
$lang['ut_line'] = 'Rindas numurs';
$lang['ut_passed'] = 'Pareizi';
$lang['ut_failed'] = 'Neveiksme';
$lang['ut_boolean'] = 'Būla';
$lang['ut_integer'] = 'Vesels skaitlis';
$lang['ut_float'] = 'Pludiņš';
$lang['ut_double'] = 'Pludiņš';
$lang['ut_string'] = 'Virkne';
$lang['ut_array'] = 'Masīvs';
$lang['ut_object'] = 'Objekts';
$lang['ut_resource'] = 'Resursi';
$lang['ut_null'] = 'Tukšs';
$lang['ut_notes'] = '';
$lang[''] = '';
?>