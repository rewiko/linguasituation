<?php

$lang['terabyte_abbr'] = 'To';
$lang['gigabyte_abbr'] = 'Go';
$lang['megabyte_abbr'] = 'Mo';
$lang['kilobyte_abbr'] = 'Ko';
$lang['bytes'] = 'Octets';
?>