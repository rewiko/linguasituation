<?php

$lang['ut_test_name'] = 'Nom du test';
$lang['ut_test_datatype'] = 'Base de donn&eacute;es du test';
$lang['ut_res_datatype'] = 'Type de donn&eacute;es attendu';
$lang['ut_result'] = 'R&eacute;sultat';
$lang['ut_undefined'] = 'Nom de test non d&eacute;fini';
$lang['ut_file'] = 'Nom du fichier';
$lang['ut_line'] = 'Num&eacute;ro de ligne';
$lang['ut_passed'] = 'Pass&eacute;';
$lang['ut_failed'] = 'Echou&eacute;';
$lang['ut_boolean'] = 'Boolean';
$lang['ut_integer'] = 'Integer';
$lang['ut_float'] = 'Float';
$lang['ut_double'] = 'Float';
$lang['ut_string'] = 'String';
$lang['ut_array'] = 'Array';
$lang['ut_object'] = 'Object';
$lang['ut_resource'] = 'Resource';
$lang['ut_null'] = 'Null';
$lang['ut_notes'] = 'Notes';
?>