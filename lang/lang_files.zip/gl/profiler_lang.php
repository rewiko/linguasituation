<?php

$lang['profiler_database'] = 'BASE DE DATOS';
$lang['profiler_controller_info'] = 'CLASE/M';
$lang['profiler_benchmarks'] = 'BENCHMARKS';
$lang['profiler_queries'] = 'CONSULTAS';
$lang['profiler_get_data'] = 'DATOS GET';
$lang['profiler_post_data'] = 'DATOS POST';
$lang['profiler_uri_string'] = 'CADEA URI';
$lang['profiler_memory_usage'] = 'USO DE MEMORIA';
$lang['profiler_config'] = '';
$lang['profiler_headers'] = '';
$lang['profiler_no_db'] = 'O driver para a base de datos non foi cargado';
$lang['profiler_no_queries'] = 'Non se executaron consultas';
$lang['profiler_no_post'] = 'Non existen datos de tipo POST';
$lang['profiler_no_get'] = 'Non existen datos de tipo GET';
$lang['profiler_no_uri'] = 'Non existen datos URI';
$lang['profiler_no_memory'] = 'Uso de memoria non dispo';
$lang['profiler_no_profiles'] = '';
$lang[''] = '';
?>