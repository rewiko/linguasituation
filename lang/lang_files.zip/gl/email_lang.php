<?php

$lang['email_must_be_array'] = 'O m';
$lang['email_invalid_address'] = 'Direcci';
$lang['email_attachment_missing'] = 'Non se puido localizar o seguinte ficheiro adjunto: %s';
$lang['email_attachment_unreadable'] = '';
$lang['email_no_recipients'] = 'Debe incluir receptores: Para, CC, ou BCC';
$lang['email_send_failure_phpmail'] = 'Non se pode enviar o correo usando a funci';
$lang['email_send_failure_sendmail'] = 'Non se pode enviar o correo usando SendMail. O seu servidor puede non estar configurado para usar este m';
$lang['email_send_failure_smtp'] = 'Non se pode enviar o correo usando SMTP PHP. O seu servidor pode non estar configurado para usar este m';
$lang['email_sent'] = 'A s';
$lang['email_no_socket'] = 'Non se pode abrir un socket para Sendmail. Por favor revise a configuraci';
$lang['email_no_hostname'] = 'Non especificou un servidor SMTP';
$lang['email_smtp_error'] = 'Os siguientes erros SMTP foron atopados: %s';
$lang['email_no_smtp_unpw'] = 'Erro: Debe asignar un usuario e contrasinal para o servidor SMTP.';
$lang['email_failed_smtp_login'] = 'Fallo enviando o comando AUTH LOGIN. Erro: %s';
$lang['email_smtp_auth_un'] = 'Fallo autentificando o usuario. Erro: %s';
$lang['email_smtp_auth_pw'] = 'Fallo usando o contrasinal. Erro: %s';
$lang['email_smtp_data_failure'] = 'Non se puideron enviar os datos: %s';
$lang['email_exit_status'] = 'C';
?>