<?php

$lang['ftp_no_connection'] = 'Non se puido localizar unha identificaci';
$lang['ftp_unable_to_connect'] = 'Non se puido conectar ao seu servidor FTP co nome de host suministrado.';
$lang['ftp_unable_to_login'] = 'Non se puido acceder ao seu servidor FTP. Por favor, comprobe o seu nome de usuario e contrasinal.';
$lang['ftp_unable_to_makdir'] = 'Non se puido crear o directorio que especificou.';
$lang['ftp_unable_to_changedir'] = 'Non se puido cambiar de directorio.';
$lang['ftp_unable_to_chmod'] = 'Non ';
$lang['ftp_unable_to_upload'] = 'Non se pode cargar o arquivo especificado. Por favor, comprobe a ruta.';
$lang['ftp_unable_to_download'] = '';
$lang['ftp_no_source_file'] = 'Non se atopa o arquivo de orixe. Por favor, comprobe a ruta.';
$lang['ftp_unable_to_rename'] = 'Non se puido renomear o arquivo.';
$lang['ftp_unable_to_delete'] = 'Non se puido borrar o arquivo.';
$lang['ftp_unable_to_move'] = 'Non ';
$lang[''] = '';
?>