<?php

$lang['upload_userfile_not_set'] = 'Non se puido atopar unha variable de tipo POST chamada userfile.';
$lang['upload_file_exceeds_limit'] = 'O arquivo subido excede o tama';
$lang['upload_file_exceeds_form_limit'] = 'O arquivo subido excede o tama';
$lang['upload_file_partial'] = 'O arquivo foi subido s';
$lang['upload_no_temp_directory'] = 'Non se atopou a carpeta temporal.';
$lang['upload_unable_to_write_file'] = 'Non se puido escribir o arquivo a disco.';
$lang['upload_stopped_by_extension'] = 'Det';
$lang['upload_no_file_selected'] = 'Non seleccionou ning';
$lang['upload_invalid_filetype'] = 'O tipo de arquivo que esta tratando de subir non est';
$lang['upload_invalid_filesize'] = 'O arquivo que est';
$lang['upload_invalid_dimensions'] = 'A imaxe que est';
$lang['upload_destination_error'] = 'Atop';
$lang['upload_no_filepath'] = 'A direcci';
$lang['upload_no_file_types'] = 'A';
$lang['upload_bad_filename'] = 'O arquivo enviado xa existe no servidor.';
$lang['upload_not_writable'] = 'Parece que non se pode escribir no directorio de destino.';
?>