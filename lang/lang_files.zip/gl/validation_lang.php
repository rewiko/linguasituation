<?php

$lang['required'] = 'O campo %s ';
$lang['isset'] = 'O campo %s debe conter un valor.';
$lang['valid_email'] = 'O campo %s debe conter unha direcci';
$lang['valid_emails'] = 'O campo %s debe conter todas as direcci';
$lang['valid_url'] = 'O campo %s debe conter unha URL v';
$lang['valid_ip'] = 'O campo %s debe conter una direcci';
$lang['min_length'] = 'O campo %s debe conter ao menos %s caracteres de lonxitude.';
$lang['max_length'] = 'O campo %s non debe exceder os %s caracteres de lonxitude.';
$lang['exact_length'] = 'O campo %s debe ter exactamente %s caracteres de lonxitude.';
$lang['alpha'] = 'O campo %s somentes pode conter caracteres alfab';
$lang['alpha_numeric'] = 'O campo %s somentes pode conter caracteres alfanum';
$lang['alpha_dash'] = 'O campo %s somentes puede conter caracteres alfanum';
$lang['numeric'] = 'O campo %s debe conter un n';
$lang['integer'] = 'O campo %s debe conter un n';
$lang['matches'] = 'O campo %s non ';
?>