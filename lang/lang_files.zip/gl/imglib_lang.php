<?php

$lang['imglib_source_image_required'] = 'Debe especificar unha imaxe de orixe nas preferencias.';
$lang['imglib_gd_required'] = '';
$lang['imglib_gd_required_for_props'] = 'O seu servidor debe soportar a librer';
$lang['imglib_unsupported_imagecreate'] = 'O seu servidor non soporta a funci';
$lang['imglib_gif_not_supported'] = 'As imaxes de tipo GIF a miudo no son soportadas poas restricci';
$lang['imglib_jpg_not_supported'] = 'O formato de imaxe JPG non est';
$lang['imglib_png_not_supported'] = 'O formato de imaxe PNG non est';
$lang['imglib_jpg_or_png_required'] = 'O protocolo de redimensionamento de imaxes especificado nas preferencias so funciona con tipos PNG ou JPG.';
$lang['imglib_copy_error'] = 'Atoparonse erros mentras se trataba de reemplazar o arquivo. Aseg';
$lang['imglib_rotate_unsupported'] = 'A rotaci';
$lang['imglib_libpath_invalid'] = 'A direcci';
$lang['imglib_image_process_failed'] = 'Procesado de imagen fallido.  Verifique que o seu servidor soporta a funci';
$lang['imglib_rotation_angle_required'] = 'Requ';
$lang['imglib_writing_failed_gif'] = 'Imaxe GIF ';
$lang['imglib_invalid_path'] = 'A dirección da imaxe non ';
$lang['imglib_copy_failed'] = 'Fallou a rutina de copia da imaxe.';
$lang['imglib_missing_font'] = 'Non se puido atopar a fonte que desexa usar.';
$lang['imglib_save_failed'] = 'Non se puido gardar a imaxe. Por favor, comprobe que os directorios onde se atopan a imaxe e o arquivo te';
?>