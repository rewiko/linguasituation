<?php

$lang['db_invalid_connection_str'] = 'Non se puido determinar a configuraci';
$lang['db_unable_to_connect'] = 'No se puido conectar ao servidor de base de datos usando a configuración suministrada.';
$lang['db_unable_to_select'] = 'No se puido seleccionar a base de datos especificada: %s';
$lang['db_unable_to_create'] = 'No se puido crear a base de datos especificada: %s';
$lang['db_invalid_query'] = 'A consulta enviada no ';
$lang['db_must_set_table'] = 'Debe especificar a t';
$lang['db_must_use_set'] = 'Debe usar o m';
$lang['db_must_use_index'] = '';
$lang['db_batch_missing_index'] = '';
$lang['db_must_use_where'] = 'As actualizaci';
$lang['db_del_must_use_where'] = 'As eliminaci';
$lang['db_field_param_missing'] = 'Para retornar campos requierese o nombre da t';
$lang['db_unsupported_function'] = 'Esta caracter';
$lang['db_transaction_failure'] = 'Fallo na transacci';
$lang['db_unable_to_drop'] = 'Non se puido eliminar a base de datos especificada.';
$lang['db_unsuported_feature'] = 'Caracter';
$lang['db_unsuported_compression'] = 'O formato de compresi';
$lang['db_filepath_error'] = 'Non se poden escribir os datos na ruta de ficheiro que proporcionou.';
$lang['db_invalid_cache_path'] = 'A ruta da cach';
$lang['db_table_name_required'] = '';
$lang['db_column_name_required'] = '';
$lang['db_column_definition_required'] = '';
$lang['db_unable_to_set_charset'] = 'Imposible establecer o xogo de caracteres de conexi';
$lang['db_error_heading'] = 'Ocurriu un Erro coa Base de Datos';
$lang[''] = '';
?>