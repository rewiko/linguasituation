<?php

$lang['required'] = 'O campo %s ';
$lang['isset'] = 'O campo %s debe conter un valor.';
$lang['valid_email'] = 'O campo %s debe conter unha direcci';
$lang['valid_emails'] = 'O campo %s debe conter todas as direcci';
$lang['valid_url'] = 'O campo %s debe conter unha URL v';
$lang['valid_ip'] = 'O campo %s debe conter unha IP v';
$lang['min_length'] = 'O campo %s debe ter ao menos %s car';
$lang['max_length'] = 'O campo %s non pode exceder os %s car';
$lang['exact_length'] = 'O campo %s debe tener exactamente %s car';
$lang['alpha'] = 'O campo %s debe conter s';
$lang['alpha_numeric'] = 'O campo %s debe conter s';
$lang['alpha_dash'] = 'O campo %s debe conter s';
$lang['numeric'] = 'O campo %s debe conter s';
$lang['is_numeric'] = 'O campo %s debe conter s';
$lang['integer'] = 'O campo %s debe conter un n';
$lang['matches'] = 'O campo %s non coincide con O campo %s.';
$lang['is_natural'] = 'O campo %s debe conter s';
$lang['is_natural_no_zero'] = 'O campo %s debe conter un n';
?>