<?php

$lang['ut_test_name'] = 'Тестово Име';
$lang['ut_test_datatype'] = 'Тестови данни';
$lang['ut_res_datatype'] = 'Очакван тип данни';
$lang['ut_result'] = 'Резултат';
$lang['ut_undefined'] = 'Не определено тестово име';
$lang['ut_file'] = 'Име на файл';
$lang['ut_line'] = 'Номер на реда';
$lang['ut_passed'] = 'Приет';
$lang['ut_failed'] = 'Проблем';
$lang['ut_boolean'] = 'Boolean';
$lang['ut_integer'] = 'Integer';
$lang['ut_float'] = 'Float';
$lang['ut_double'] = 'Float';
$lang['ut_string'] = 'Низ';
$lang['ut_array'] = 'Array';
$lang['ut_object'] = 'Обект';
$lang['ut_resource'] = 'Ресурси';
$lang['ut_null'] = 'Null';
$lang['ut_notes'] = 'Бележка';
?>