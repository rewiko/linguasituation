<?php

$lang['ftp_no_connection'] = 'Tidak dapat mencari sambungan ID yang sah. Pastikan anda terhubung sebelum menjalankan sebarang rutin fail.';
$lang['ftp_unable_to_connect'] = 'Tidak dapat bersambung ke pelayan FTP anda menggunakan hostname disediakan.';
$lang['ftp_unable_to_login'] = 'Tidak dapat log masuk ke pelayan FTP anda. Sila semak nama pengguna anda dan katalaluan.';
$lang['ftp_unable_to_makdir'] = 'Tidak boleh membuat direktori yang anda tentukan.';
$lang['ftp_unable_to_changedir'] = 'Direktori tidak dapat ditukar.';
$lang['ftp_unable_to_chmod'] = 'Tidak dapat menetapkan keizinan fail. Sila semak path anda. Nota: Ciri ini hanya terdapat di PHP 5 atau lebih.';
$lang['ftp_unable_to_upload'] = 'Tidak dapat memuatnaik fail yang ditetapkan. Sila semak path anda.';
$lang['ftp_unable_to_download'] = 'Tidak dapat memuatturun fail yang ditetapkan. Sila semak path anda.';
$lang['ftp_no_source_file'] = 'Tidak dapat mencari fail sumber. Sila semak path anda.';
$lang['ftp_unable_to_rename'] = 'Fail tersebut tidak dapat ditukar nama.';
$lang['ftp_unable_to_delete'] = 'Fail tersebut tidak dapat dibuang.';
$lang['ftp_unable_to_move'] = 'Fail tersebut tidak dapat dipindahkan. Pastikan direktori destinasi anda wujud.';
?>