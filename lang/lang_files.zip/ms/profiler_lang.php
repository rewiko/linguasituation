<?php

$lang['profiler_database'] = 'PENGKALAN DATA';
$lang['profiler_controller_info'] = 'KELAS/FUNGSI';
$lang['profiler_benchmarks'] = 'PENANDA ARAS';
$lang['profiler_queries'] = 'PERTANYAAN';
$lang['profiler_get_data'] = 'DATA GET';
$lang['profiler_post_data'] = 'DATA POST';
$lang['profiler_uri_string'] = 'STRING URI';
$lang['profiler_memory_usage'] = 'MEMORI PENGGUNAAN';
$lang['profiler_config'] = 'PEMBOLEHUBAH CONFIG';
$lang['profiler_headers'] = 'KEPALA HTTP';
$lang['profiler_no_db'] = 'Pemacu pangkalan data tidak dimuatkan';
$lang['profiler_no_queries'] = 'Tiada arahan yang dilaksanakan';
$lang['profiler_no_post'] = 'Tiada data POST';
$lang['profiler_no_get'] = 'Tiada data GET';
$lang['profiler_no_uri'] = 'Tiada URI data';
$lang['profiler_no_memory'] = 'Tiada Memori Penggunaan';
$lang['profiler_no_profiles'] = 'Tiada data Profail - Semua seksyen Profiler telah dilumpuhkan';
?>