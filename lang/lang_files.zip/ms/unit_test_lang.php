<?php

$lang['ut_test_name'] = 'Nama Ujian';
$lang['ut_test_datatype'] = 'Jenis Data Ujian';
$lang['ut_res_datatype'] = 'Jenis Data Yang Dijangka';
$lang['ut_result'] = 'Keputusan';
$lang['ut_undefined'] = 'Nama Ujian Gagal Dikenalpasti';
$lang['ut_file'] = 'Nama Fail';
$lang['ut_line'] = 'Nombor Baris';
$lang['ut_passed'] = 'Lulus';
$lang['ut_failed'] = 'Gagal';
$lang['ut_boolean'] = 'Boolean';
$lang['ut_integer'] = 'Integer';
$lang['ut_float'] = 'Perpuluhan';
$lang['ut_double'] = 'Perpuluhan';
$lang['ut_string'] = 'String';
$lang['ut_array'] = 'Array';
$lang['ut_object'] = 'Objek';
$lang['ut_resource'] = 'Sumber';
$lang['ut_null'] = 'Null';
$lang['ut_notes'] = 'Nota';
?>