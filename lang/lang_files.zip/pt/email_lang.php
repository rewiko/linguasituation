<?php

$lang['email_must_be_array'] = 'O m';
$lang['email_invalid_address'] = 'Endere';
$lang['email_attachment_missing'] = 'N';
$lang['email_attachment_unreadable'] = 'N';
$lang['email_no_recipients'] = 'Voc';
$lang['email_send_failure_phpmail'] = 'N';
$lang['email_send_failure_sendmail'] = 'N';
$lang['email_send_failure_smtp'] = 'N';
$lang['email_sent'] = 'Sua mensagem foi enviada com sucesso utilizando o seguinte protocolo: %s';
$lang['email_no_socket'] = 'N';
$lang['email_no_hostname'] = 'Voc';
$lang['email_smtp_error'] = 'Os seguintes erros de SMTP foram encontrados: %s';
$lang['email_no_smtp_unpw'] = 'Erro: Voc';
$lang['email_failed_smtp_login'] = 'Falha ao enviar o comando AUTH LOGIN. Erro: %s';
$lang['email_smtp_auth_un'] = 'Falha ao autenticar o usu';
$lang['email_smtp_auth_pw'] = 'Falha ao autenticar a senha. Erro: %s';
$lang['email_smtp_data_failure'] = 'N';
$lang['email_exit_status'] = '';
?>