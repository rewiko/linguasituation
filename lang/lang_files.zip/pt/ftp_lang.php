<?php

$lang['ftp_no_connection'] = 'N';
$lang['ftp_unable_to_connect'] = 'N';
$lang['ftp_unable_to_login'] = 'N';
$lang['ftp_unable_to_makdir'] = 'N';
$lang['ftp_unable_to_changedir'] = 'N';
$lang['ftp_unable_to_chmod'] = 'N';
$lang['ftp_unable_to_upload'] = 'N';
$lang['ftp_unable_to_download'] = '';
$lang['ftp_no_source_file'] = 'N';
$lang['ftp_unable_to_rename'] = 'N';
$lang['ftp_unable_to_delete'] = 'N';
$lang['ftp_unable_to_move'] = 'N';
$lang[''] = '';
?>