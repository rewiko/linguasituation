<?php

$lang['imglib_source_image_required'] = 'Voc';
$lang['imglib_gd_required'] = 'A biblioteca de imagens GD ';
$lang['imglib_gd_required_for_props'] = 'Seu servidor deve suportar a biblioteca de imagens GD para determinar as propriedades dessa imagem.';
$lang['imglib_unsupported_imagecreate'] = 'Seu servidor n';
$lang['imglib_gif_not_supported'] = 'Imagens GIF n';
$lang['imglib_jpg_not_supported'] = 'Imagens JPG n';
$lang['imglib_png_not_supported'] = 'Imagens PNG n';
$lang['imglib_jpg_or_png_required'] = 'O protocolo de redimensionamento de imagens espeficicada em suas prefer';
$lang['imglib_copy_error'] = 'Um erro foi encontrado enquanto tentava substituir o arquivo. Confira se o arquivo e o diret';
$lang['imglib_rotate_unsupported'] = 'Rota';
$lang['imglib_libpath_invalid'] = 'O caminho para a biblioteca de imagens n';
$lang['imglib_image_process_failed'] = 'Processo da imagem falhou. Verifique se o seu servidor suporta o protocolo escolhido e o caminho para a sua biblioteca gr';
$lang['imglib_rotation_angle_required'] = 'Um ';
$lang['imglib_writing_failed_gif'] = 'Imagem GIF.';
$lang['imglib_invalid_path'] = 'O caminho para a imagem n';
$lang['imglib_copy_failed'] = 'A rotina de copia da imagem falhou.';
$lang['imglib_missing_font'] = 'N';
$lang['imglib_save_failed'] = '';
?>