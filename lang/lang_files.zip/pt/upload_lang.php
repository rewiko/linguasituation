<?php

$lang['upload_userfile_not_set'] = 'N';
$lang['upload_file_exceeds_limit'] = 'O arquivo enviado excede o tamanho m';
$lang['upload_file_exceeds_form_limit'] = 'O arquivo enviado excede o tamanho m';
$lang['upload_file_partial'] = 'O arquivo foi parcialmente enviado.';
$lang['upload_no_temp_directory'] = 'A pasta tempor';
$lang['upload_unable_to_write_file'] = 'O arquivo n';
$lang['upload_stopped_by_extension'] = 'O arquivo n';
$lang['upload_no_file_selected'] = 'Voc';
$lang['upload_invalid_filetype'] = 'O tipo de arquivo enviado n';
$lang['upload_invalid_filesize'] = 'O arquivo que voc';
$lang['upload_invalid_dimensions'] = 'A imagem que voc';
$lang['upload_destination_error'] = 'Um problema foi encontrado enquanto tentava mover o arquivo enviado para o destino final.';
$lang['upload_no_filepath'] = 'O caminho do envio n';
$lang['upload_no_file_types'] = 'Voc';
$lang['upload_bad_filename'] = 'O nome do arquivo que voc';
$lang['upload_not_writable'] = 'A pasta de envio n';
?>