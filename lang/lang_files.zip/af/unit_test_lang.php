<?php

$lang['ut_test_name'] = '';
$lang['ut_test_datatype'] = '';
$lang['ut_res_datatype'] = '';
$lang['ut_result'] = '';
$lang['ut_undefined'] = '';
$lang['ut_file'] = '';
$lang['ut_line'] = '';
$lang['ut_passed'] = '';
$lang['ut_failed'] = '';
$lang['ut_boolean'] = '';
$lang['ut_integer'] = '';
$lang['ut_float'] = '';
$lang['ut_double'] = '';
$lang['ut_string'] = '';
$lang['ut_array'] = '';
$lang['ut_object'] = '';
$lang['ut_resource'] = '';
$lang['ut_null'] = '';
$lang['ut_notes'] = '';
$lang[''] = '';
?>