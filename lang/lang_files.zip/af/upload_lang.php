<?php

$lang['upload_userfile_not_set'] = '';
$lang['upload_file_exceeds_limit'] = '';
$lang['upload_file_exceeds_form_limit'] = '';
$lang['upload_file_partial'] = '';
$lang['upload_no_temp_directory'] = '';
$lang['upload_unable_to_write_file'] = '';
$lang['upload_stopped_by_extension'] = '';
$lang['upload_no_file_selected'] = '';
$lang['upload_invalid_filetype'] = '';
$lang['upload_invalid_filesize'] = '';
$lang['upload_invalid_dimensions'] = '';
$lang['upload_destination_error'] = '';
$lang['upload_no_filepath'] = '';
$lang['upload_no_file_types'] = '';
$lang['upload_bad_filename'] = '';
$lang['upload_not_writable'] = '';
$lang[''] = '';
?>