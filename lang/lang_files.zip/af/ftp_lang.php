<?php

$lang['ftp_no_connection'] = '';
$lang['ftp_unable_to_connect'] = '';
$lang['ftp_unable_to_login'] = '';
$lang['ftp_unable_to_makdir'] = '';
$lang['ftp_unable_to_changedir'] = '';
$lang['ftp_unable_to_chmod'] = '';
$lang['ftp_unable_to_upload'] = '';
$lang['ftp_unable_to_download'] = '';
$lang['ftp_no_source_file'] = '';
$lang['ftp_unable_to_rename'] = '';
$lang['ftp_unable_to_delete'] = '';
$lang['ftp_unable_to_move'] = '';
$lang[''] = '';
?>