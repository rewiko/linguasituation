<?php

$lang['imglib_source_image_required'] = '';
$lang['imglib_gd_required'] = '';
$lang['imglib_gd_required_for_props'] = '';
$lang['imglib_unsupported_imagecreate'] = '';
$lang['imglib_gif_not_supported'] = '';
$lang['imglib_jpg_not_supported'] = '';
$lang['imglib_png_not_supported'] = '';
$lang['imglib_jpg_or_png_required'] = '';
$lang['imglib_copy_error'] = '';
$lang['imglib_rotate_unsupported'] = '';
$lang['imglib_libpath_invalid'] = '';
$lang['imglib_image_process_failed'] = '';
$lang['imglib_rotation_angle_required'] = '';
$lang['imglib_writing_failed_gif'] = '';
$lang['imglib_invalid_path'] = '';
$lang['imglib_copy_failed'] = '';
$lang['imglib_missing_font'] = '';
$lang['imglib_save_failed'] = '';
$lang[''] = '';
?>