<?php

$lang['required'] = '';
$lang['isset'] = '';
$lang['valid_email'] = '';
$lang['valid_emails'] = '';
$lang['valid_url'] = '';
$lang['valid_ip'] = '';
$lang['min_length'] = '';
$lang['max_length'] = '';
$lang['exact_length'] = '';
$lang['alpha'] = '';
$lang['alpha_numeric'] = '';
$lang['alpha_dash'] = '';
$lang['numeric'] = '';
$lang['integer'] = '';
$lang['matches'] = '';
$lang[''] = '';
?>