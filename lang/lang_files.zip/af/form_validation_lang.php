<?php

$lang['required'] = '';
$lang['isset'] = '';
$lang['valid_email'] = '';
$lang['valid_emails'] = '';
$lang['valid_url'] = '';
$lang['valid_ip'] = '';
$lang['min_length'] = '';
$lang['max_length'] = '';
$lang['exact_length'] = '';
$lang['alpha'] = '';
$lang['alpha_numeric'] = '';
$lang['alpha_dash'] = '';
$lang['numeric'] = '';
$lang['is_numeric'] = '';
$lang['integer'] = '';
$lang['matches'] = '';
$lang['is_natural'] = '';
$lang['is_natural_no_zero'] = '';
$lang[''] = '';
?>