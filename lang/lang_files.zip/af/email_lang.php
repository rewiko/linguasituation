<?php

$lang['email_must_be_array'] = '';
$lang['email_invalid_address'] = '';
$lang['email_attachment_missing'] = '';
$lang['email_attachment_unreadable'] = '';
$lang['email_no_recipients'] = '';
$lang['email_send_failure_phpmail'] = '';
$lang['email_send_failure_sendmail'] = '';
$lang['email_send_failure_smtp'] = '';
$lang['email_sent'] = '';
$lang['email_no_socket'] = '';
$lang['email_no_hostname'] = '';
$lang['email_smtp_error'] = '';
$lang['email_no_smtp_unpw'] = '';
$lang['email_failed_smtp_login'] = '';
$lang['email_smtp_auth_un'] = '';
$lang['email_smtp_auth_pw'] = '';
$lang['email_smtp_data_failure'] = '';
$lang['email_exit_status'] = '';
$lang[''] = '';
?>