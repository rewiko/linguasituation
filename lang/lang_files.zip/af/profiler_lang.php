<?php

$lang['profiler_database'] = '';
$lang['profiler_controller_info'] = '';
$lang['profiler_benchmarks'] = '';
$lang['profiler_queries'] = '';
$lang['profiler_get_data'] = '';
$lang['profiler_post_data'] = '';
$lang['profiler_uri_string'] = '';
$lang['profiler_memory_usage'] = '';
$lang['profiler_config'] = '';
$lang['profiler_headers'] = '';
$lang['profiler_no_db'] = '';
$lang['profiler_no_queries'] = '';
$lang['profiler_no_post'] = '';
$lang['profiler_no_get'] = '';
$lang['profiler_no_uri'] = '';
$lang['profiler_no_memory'] = '';
$lang['profiler_no_profiles'] = '';
$lang[''] = '';
?>