<?php

$lang['terabyte_abbr'] = '';
$lang['gigabyte_abbr'] = '';
$lang['megabyte_abbr'] = '';
$lang['kilobyte_abbr'] = '';
$lang['bytes'] = '';
$lang[''] = '';
?>