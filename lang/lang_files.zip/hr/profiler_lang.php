<?php

$lang['profiler_database'] = 'BAZA PODATAKA';
$lang['profiler_controller_info'] = 'RAZREDI/METODE';
$lang['profiler_benchmarks'] = 'MJERILO';
$lang['profiler_queries'] = 'UPITI';
$lang['profiler_get_data'] = 'GET PODACI';
$lang['profiler_post_data'] = 'POST PODACI';
$lang['profiler_uri_string'] = 'URI STRING';
$lang['profiler_memory_usage'] = 'UPOTREBA MEMORIJE';
$lang['profiler_config'] = '';
$lang['profiler_headers'] = '';
$lang['profiler_no_db'] = 'Driver za bazu trenutno nije učitan';
$lang['profiler_no_queries'] = 'Nema zadanih upita';
$lang['profiler_no_post'] = 'Nema POST podataka';
$lang['profiler_no_get'] = 'Nema GET podataka';
$lang['profiler_no_uri'] = 'Nema URI podataka';
$lang['profiler_no_memory'] = 'Pregled iskoristivosti memorije nije dostupan';
$lang['profiler_no_profiles'] = '';
$lang[''] = '';
?>