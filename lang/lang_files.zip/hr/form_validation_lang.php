<?php

$lang['required'] = 'Morate ispuniti polje "%s".';
$lang['isset'] = 'Morate ispuniti polje "%s".';
$lang['valid_email'] = 'Polje "%s" mora sadr';
$lang['valid_emails'] = 'Polje "%s" mora sadr';
$lang['valid_url'] = 'Polje "%s" mora sadr';
$lang['valid_ip'] = 'Polje "%s" mora sadr';
$lang['min_length'] = 'Polje "%s" mora biti duga';
$lang['max_length'] = 'Polje "%s" ne mo';
$lang['exact_length'] = 'Polje "%s" mora biti to';
$lang['alpha'] = 'Polje "%s" mo';
$lang['alpha_numeric'] = 'Polje "%s" mo';
$lang['alpha_dash'] = 'Polje "%s" mo';
$lang['numeric'] = 'Polje "%s" mora sadr';
$lang['is_numeric'] = 'Polje "%s" mora sadr';
$lang['integer'] = 'Polje "%s" mora sadr';
$lang['matches'] = 'Polje "%s" ne poklapa se sa poljem %s.';
$lang['is_natural'] = 'Polje "%s" mora sadr';
$lang['is_natural_no_zero'] = 'Polje "%s" mora sadr';
?>