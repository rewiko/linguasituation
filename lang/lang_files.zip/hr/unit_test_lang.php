<?php

$lang['ut_test_name'] = 'Naziv testa';
$lang['ut_test_datatype'] = 'Tip podataka';
$lang['ut_res_datatype'] = 'Očekivani tip podataka';
$lang['ut_result'] = 'Rezultat';
$lang['ut_undefined'] = 'Nedefiniran naziv testa';
$lang['ut_file'] = 'Naziv datoteke';
$lang['ut_line'] = 'Broj linije';
$lang['ut_passed'] = 'Prošao';
$lang['ut_failed'] = 'Neuspjelo';
$lang['ut_boolean'] = 'Boolean';
$lang['ut_integer'] = 'Integer';
$lang['ut_float'] = 'Float';
$lang['ut_double'] = 'Float';
$lang['ut_string'] = 'String';
$lang['ut_array'] = 'Array';
$lang['ut_object'] = 'Objekt';
$lang['ut_resource'] = 'Resource';
$lang['ut_null'] = 'Null';
$lang['ut_notes'] = '';
$lang[''] = '';
?>