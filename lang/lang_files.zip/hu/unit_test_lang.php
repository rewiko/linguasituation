<?php

$lang['ut_test_name'] = 'Teszt név';
$lang['ut_test_datatype'] = 'Teszt adattípus';
$lang['ut_res_datatype'] = 'Várt adattípus';
$lang['ut_result'] = 'Eredmény';
$lang['ut_undefined'] = 'Definiálatlan teszt név';
$lang['ut_file'] = 'Fájl név';
$lang['ut_line'] = 'Sor száma';
$lang['ut_passed'] = 'Siker';
$lang['ut_failed'] = 'Hiba';
$lang['ut_boolean'] = 'Boolean';
$lang['ut_integer'] = 'Integer';
$lang['ut_float'] = 'Float';
$lang['ut_double'] = 'Float';
$lang['ut_string'] = 'String';
$lang['ut_array'] = 'Array';
$lang['ut_object'] = 'Object';
$lang['ut_resource'] = 'Resource';
$lang['ut_null'] = 'Null';
$lang['ut_notes'] = '';
$lang[''] = '';
?>