<?php

$lang['ftp_no_connection'] = '正しい接続IDが見つかりませんb。ファイル処理を実行する前に接続してください。';
$lang['ftp_unable_to_connect'] = '指定されたホスト名のFTPサーバに接続できません。';
$lang['ftp_unable_to_login'] = '指定されたFTPサーバにログインできません。ユーザ名とパスワードを確認してください。';
$lang['ftp_unable_to_makdir'] = '指定されたディレクトリを作成できません。';
$lang['ftp_unable_to_changedir'] = 'カレントディレクトリを変更できません。';
$lang['ftp_unable_to_chmod'] = 'パーミッションを変更できません。パスを確認してください。※この機能はPHP5以降のみでサポートされます。';
$lang['ftp_unable_to_upload'] = '指定されたファイルをアップロードできません。パスを確認してください。';
$lang['ftp_unable_to_download'] = '';
$lang['ftp_no_source_file'] = '転送元ファイルが見つかりません。パスを確認してください。';
$lang['ftp_unable_to_rename'] = 'ファイル名の変更ができません。';
$lang['ftp_unable_to_delete'] = 'ファイルを削除できません。';
$lang['ftp_unable_to_move'] = 'ファイルを移動できません。移動先のディレクトリが存在するか確認してください。';
$lang[''] = '';
?>