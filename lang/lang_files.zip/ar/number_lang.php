<?php

$lang['terabyte_abbr'] = 'تيرا بايت';
$lang['gigabyte_abbr'] = 'جيغا بايت';
$lang['megabyte_abbr'] = 'ميغا';
$lang['kilobyte_abbr'] = 'كيلو بايت';
$lang['bytes'] = 'بايت';
?>