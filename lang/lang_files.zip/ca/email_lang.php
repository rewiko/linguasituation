<?php

$lang['email_must_be_array'] = 'El m&egrave;tode de validaci&oacute; del correu ha de ser de tipus array.';
$lang['email_invalid_address'] = 'Dirreci&oacute; de correu no v&agrave;lida: %s';
$lang['email_attachment_missing'] = 'No s\'ha pogut localitzar el seg&uuml;ent fitxer adjunt: %s';
$lang['email_attachment_unreadable'] = '';
$lang['email_no_recipients'] = 'Cal incloure receptors: Para, CC, o BCC';
$lang['email_send_failure_phpmail'] = 'No es pot enviar el correu utilitzant la funci&oacute; mail() de PHP. El servidor pot no estar configurat per utilitzar aquest m&egrave;tode d\'enviament.';
$lang['email_send_failure_sendmail'] = 'No es pot enviar el correu usant SendMail. El servidor pot no estar configurat per utilitzar aquest m&egrave;tode d\'enviament.';
$lang['email_send_failure_smtp'] = 'No es pot enviar el correu usant SMTP PHP. El servidor pot no estar configurat per utilitzar aquest m&egrave;tode d\'enviament.';
$lang['email_sent'] = 'El seu missatge ha estat enviat satisfact&ograve;çriament utilitzant el seg&uuml;ent protocol: %s';
$lang['email_no_socket'] = 'No es pot obrir un socket per Sendmail. Si us plau revisi la configuraci&oacute;.';
$lang['email_no_hostname'] = 'No ha especificat un servidor SMTP';
$lang['email_smtp_error'] = 'Els seg&uuml;ents errors SMTP han estat trobats: %s';
$lang['email_no_smtp_unpw'] = 'Error: Cal assignar un usuari i una contrassenya pel servidor SMTP.';
$lang['email_failed_smtp_login'] = 'Error enviant l\'ordre AUTH LOGIN. Error: %s';
$lang['email_smtp_auth_un'] = 'Error autentificant l\'usuari. Error: %s';
$lang['email_smtp_auth_pw'] = 'Error utilitzant la contrassenya. Error: %s';
$lang['email_smtp_data_failure'] = 'No s\'han pogut enviar les dades: %s';
$lang['email_exit_status'] = 'Codi d\'estat de sortida: %s';
$lang[''] = '';
?>