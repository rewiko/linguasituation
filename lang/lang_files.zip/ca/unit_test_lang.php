<?php

$lang['ut_test_name'] = 'Nom del test';
$lang['ut_test_datatype'] = 'Tipus de dades del test';
$lang['ut_res_datatype'] = 'Tipus de dades esperats';
$lang['ut_result'] = 'Resultat';
$lang['ut_undefined'] = 'Nom del test no definit';
$lang['ut_file'] = 'Nom del fitxer';
$lang['ut_line'] = 'N&uacute;mero de l&iacute;nia';
$lang['ut_passed'] = 'Correcte';
$lang['ut_failed'] = 'Error';
$lang['ut_boolean'] = 'Boolean';
$lang['ut_integer'] = 'Integer';
$lang['ut_float'] = 'Float';
$lang['ut_double'] = 'Float';
$lang['ut_string'] = 'String';
$lang['ut_array'] = 'Array';
$lang['ut_object'] = 'Object';
$lang['ut_resource'] = 'Resource';
$lang['ut_null'] = 'Null';
$lang['ut_notes'] = '';
$lang[''] = '';
?>