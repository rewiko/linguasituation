<?php

$lang['ftp_no_connection'] = 'No s\'ha pogut localitzar una identificaci&oacute; de connexi&oacute; v&agrave;lida. Si us plau, asseguri\'s que est&agrave; connectat abans de realitzar qualsevol rutina amb arxius.';
$lang['ftp_unable_to_connect'] = 'No s\'ha pogut connectar al seu servidor FTP amb el nom d\'"host" introdu&iuml;t.';
$lang['ftp_unable_to_login'] = 'No s\'ha pogut accedir al seu servidor FTP. Siusplau, comprovi el seu nom d\'usuari i contrassenya.';
$lang['ftp_unable_to_makdir'] = 'No s\'ha pogut crear el directori que s\'ha especificat.';
$lang['ftp_unable_to_changedir'] = 'No s\'ha pogut canviar el directori.';
$lang['ftp_unable_to_chmod'] = 'No &eacute;s possible establir permisos d\'arxius. Si us plau, comprovi la ruta. Nota: Aquesta funci&oacute; nom&eacute;s est&agrave; disponible en PHP 5 o superior.';
$lang['ftp_unable_to_upload'] = 'No s\'ha pogut carregar l\'arxiu especificat. Si us plau comprovi la ruta.';
$lang['ftp_unable_to_download'] = '';
$lang['ftp_no_source_file'] = 'No es troba l\'arxiu d\'origen. Si us plau, comprovi la ruta.';
$lang['ftp_unable_to_rename'] = 'No s\'ha pogut reanomenar l\'arxiu.';
$lang['ftp_unable_to_delete'] = 'No s\'ha pogut eliminar l\'arxiu.';
$lang['ftp_unable_to_move'] = 'No és possible moure l\'arxiu. Si us plau, asseguri\'s que el directori de destinaci&oacute; existeix.';
$lang[''] = '';
?>