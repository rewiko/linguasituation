<?php

$lang['profiler_database'] = 'BASE DE DADES';
$lang['profiler_controller_info'] = 'CLASSE/M&Egrave;TODE';
$lang['profiler_benchmarks'] = 'BENCHMARKS';
$lang['profiler_queries'] = 'CONSULTES';
$lang['profiler_get_data'] = 'DADES GET';
$lang['profiler_post_data'] = 'DADES POST';
$lang['profiler_uri_string'] = 'CADENA URI';
$lang['profiler_memory_usage'] = '&Uacute;S DE MEM&Ograve;RIA';
$lang['profiler_config'] = '';
$lang['profiler_headers'] = '';
$lang['profiler_no_db'] = 'El driver per la base de dades no ha estat carregat';
$lang['profiler_no_queries'] = 'No s\'han executat consultes';
$lang['profiler_no_post'] = 'No existeixen dades de tipus POST';
$lang['profiler_no_get'] = 'No existeixen dades de tipus GET';
$lang['profiler_no_uri'] = 'No existeixen dades URI';
$lang['profiler_no_memory'] = '&Uacute;s de mem&ograve;ria no disponible';
$lang['profiler_no_profiles'] = '';
$lang[''] = '';
?>