<?php

$lang['required'] = '%s feltet skal udfyldes.';
$lang['isset'] = '%s feltet skal have en v';
$lang['valid_email'] = '%s feltet skal indeholde en gyldig email adresse.';
$lang['valid_emails'] = '%s feltet m';
$lang['valid_url'] = '%s feltet skal indeholde et gyldigt URL.';
$lang['valid_ip'] = '%s feltet skal indeholde en gyldig IP adresse.';
$lang['min_length'] = '%s feltet skal v';
$lang['max_length'] = '%s feltet m';
$lang['exact_length'] = '%s feltet skal v';
$lang['alpha'] = '%s feltet m';
$lang['alpha_numeric'] = '%s feltet m';
$lang['alpha_dash'] = '%s feltet m';
$lang['numeric'] = '%s feltet m';
$lang['is_numeric'] = '%s feltet m';
$lang['integer'] = '%s feltet skal indeholde et helt nummer.';
$lang['matches'] = '%s feltet mathcer ikke %s feltet.';
$lang['is_natural'] = '%s feltet m';
$lang['is_natural_no_zero'] = '%s feltet skal indeholde et nummer st';
?>