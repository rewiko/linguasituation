<?php

$lang['ftp_no_connection'] = 'Ude af stand til at lokalisere et gyldigt forbindelses ID. Tjek venligst om du er forbundet f';
$lang['ftp_unable_to_connect'] = 'Ude af standt til at forbinde til FTP serveren med det angivne hostname.';
$lang['ftp_unable_to_login'] = 'Ude af standt til at logge ind p';
$lang['ftp_unable_to_makdir'] = 'Ude af standt til oprette den mappe du har angivet.';
$lang['ftp_unable_to_changedir'] = 'Ude af standt til at skifte mappe.';
$lang['ftp_unable_to_chmod'] = 'Ude af standt til at ';
$lang['ftp_unable_to_upload'] = 'Ude af standt til at uploade den angivne fil. Tjek venligst stien.';
$lang['ftp_unable_to_download'] = '';
$lang['ftp_no_source_file'] = 'Ude af standt til lokalisere kildefilen. Tjek venligst din sti.';
$lang['ftp_unable_to_rename'] = 'Ude af standt til at ';
$lang['ftp_unable_to_delete'] = 'Ude af standt til at slette filen.';
$lang['ftp_unable_to_move'] = 'Ude af standt til flytte filen. Tjek venligst at destinationsmappen eksisterer.';
$lang[''] = '';
?>