<?php

$lang['imglib_source_image_required'] = 'Du skal specificere et kilde billede i dine pr';
$lang['imglib_gd_required'] = 'GD billede biblioteket er p';
$lang['imglib_gd_required_for_props'] = 'Din server skal underst';
$lang['imglib_unsupported_imagecreate'] = 'Din server underst';
$lang['imglib_gif_not_supported'] = 'GIF billedet underst';
$lang['imglib_jpg_not_supported'] = 'JPG billeder underst';
$lang['imglib_png_not_supported'] = 'PNG billeder underst';
$lang['imglib_jpg_or_png_required'] = 'Protokollen for ';
$lang['imglib_copy_error'] = 'En fejl opstod i fors';
$lang['imglib_rotate_unsupported'] = 'Billede retation ser ikke ud til at v';
$lang['imglib_libpath_invalid'] = 'Stien til dit billede bibliotek er ikke korrekt. Angiv venligst den korrekte sti i dine billede pr';
$lang['imglib_image_process_failed'] = 'Billede forarbejdelse fejlede. Tjek venligst at din server underst';
$lang['imglib_rotation_angle_required'] = 'En vinkel er p';
$lang['imglib_writing_failed_gif'] = 'GIF billede.';
$lang['imglib_invalid_path'] = 'Stien til billedet er ikke korrekt.';
$lang['imglib_copy_failed'] = 'Billed kopierings processen fejlede.';
$lang['imglib_missing_font'] = 'Ude af stand til at finde en skriftype at bruge.';
$lang['imglib_save_failed'] = '';
?>