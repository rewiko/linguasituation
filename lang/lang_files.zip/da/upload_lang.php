<?php

$lang['upload_userfile_not_set'] = 'Ude af stand til at finde en post variabel kaldet usefile.';
$lang['upload_file_exceeds_limit'] = 'Den uploadede fil overskrider den maksimale st';
$lang['upload_file_exceeds_form_limit'] = 'Den uploadede fil overskrider den maksimale st';
$lang['upload_file_partial'] = 'Filen blev kun delvist uploadet.';
$lang['upload_no_temp_directory'] = 'Den midlertidige folder mangler.';
$lang['upload_unable_to_write_file'] = 'Filen kunne ikke blive skrevet til disken.';
$lang['upload_stopped_by_extension'] = 'Indseldelsen af filen blev stoppet af filtypen.';
$lang['upload_no_file_selected'] = 'Du valgte ikke en fil at uploade.';
$lang['upload_invalid_filetype'] = 'Filtypen du fors';
$lang['upload_invalid_filesize'] = 'Filen du fors';
$lang['upload_invalid_dimensions'] = 'Billedet du fors';
$lang['upload_destination_error'] = 'Der opstod et problem i fors';
$lang['upload_no_filepath'] = 'Upload stien ser ikke ud til at v';
$lang['upload_no_file_types'] = 'Der er ikke specificeret nogen tilladte filtyper.';
$lang['upload_bad_filename'] = 'Navnet p';
$lang['upload_not_writable'] = 'Destinationsfolderen for de uploadede filer ser ikke ud til at v';
?>